#ifndef __FREECARS_ISR_H_
#define __FREECARS_ISR_H_

#include "stm32f4xx.h"
#define UInt32 uint32_t
#define Int16 int16_t

#endif
